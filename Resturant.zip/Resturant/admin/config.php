<?php
error_reporting(1);
mysql_connect("localhost","root","toor");
mysql_select_db("pizza_inn");
?>

	<?php
    define('DB_HOST', 'localhost');
    define('DB_USER', 'root');
    define('DB_PASSWORD', 'toor');
    define('DB_DATABASE', 'pizza_inn');
?>

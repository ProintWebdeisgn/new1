/*!
 * ASP.NET SignalR JavaScript Library v2.2.1
 * http://signalr.net/
 *
 * Copyright (c) .NET Foundation. All rights reserved.
 * Licensed under the Apache License, Version 2.0. See License.txt in the project root for license information.
 *
 */

/// <reference path="..\..\SignalR.Client.JS\Scripts\jquery-1.6.4.js" />
/// <reference path="jquery.signalR.js" />
(function ($, window, undefined) {
    /// <param name="$" type="jQuery" />
    "use strict";

    if (typeof ($.signalR) !== "function") {
        throw new Error("SignalR: SignalR is not loaded. Please ensure jquery.signalR-x.js is referenced before ~/signalr/js.");
    }

    var signalR = $.signalR;

    function makeProxyCallback(hub, callback) {
        return function () {
            // Call the client hub method
            callback.apply(hub, $.makeArray(arguments));
        };
    }

    function registerHubProxies(instance, shouldSubscribe) {
        var key, hub, memberKey, memberValue, subscriptionMethod;

        for (key in instance) {
            if (instance.hasOwnProperty(key)) {
                hub = instance[key];

                if (!(hub.hubName)) {
                    // Not a client hub
                    continue;
                }

                if (shouldSubscribe) {
                    // We want to subscribe to the hub events
                    subscriptionMethod = hub.on;
                } else {
                    // We want to unsubscribe from the hub events
                    subscriptionMethod = hub.off;
                }

                // Loop through all members on the hub and find client hub functions to subscribe/unsubscribe
                for (memberKey in hub.client) {
                    if (hub.client.hasOwnProperty(memberKey)) {
                        memberValue = hub.client[memberKey];

                        if (!$.isFunction(memberValue)) {
                            // Not a client hub function
                            continue;
                        }

                        subscriptionMethod.call(hub, memberKey, makeProxyCallback(hub, memberValue));
                    }
                }
            }
        }
    }

    $.hubConnection.prototype.createHubProxies = function () {
        var proxies = {};
        this.starting(function () {
            // Register the hub proxies as subscribed
            // (instance, shouldSubscribe)
            registerHubProxies(proxies, true);

            this._registerSubscribedHubs();
        }).disconnected(function () {
            // Unsubscribe all hub proxies when we "disconnect".  This is to ensure that we do not re-add functional call backs.
            // (instance, shouldSubscribe)
            registerHubProxies(proxies, false);
        });

        proxies['chatHub'] = this.createHubProxy('chatHub'); 
        proxies['chatHub'].client = { };
        proxies['chatHub'].server = {
            atLogin: function (status, operatorName, operatorId, type, message, userMobileNo, userEmailId, img) {
                return proxies['chatHub'].invoke.apply(proxies['chatHub'], $.merge(["AtLogin"], $.makeArray(arguments)));
             },

            bulkTransferUserToOtherOperator: function (userConnectionID, operatorfromConnectionID, operatortoConnectionID, chatDuration) {
                return proxies['chatHub'].invoke.apply(proxies['chatHub'], $.merge(["BulkTransferUserToOtherOperator"], $.makeArray(arguments)));
             },

            changeOperatorStatus: function () {
                return proxies['chatHub'].invoke.apply(proxies['chatHub'], $.merge(["ChangeOperatorStatus"], $.makeArray(arguments)));
             },

            changeUserConnectionStatus: function (status) {
                return proxies['chatHub'].invoke.apply(proxies['chatHub'], $.merge(["ChangeUserConnectionStatus"], $.makeArray(arguments)));
             },

            checkin: function () {
                return proxies['chatHub'].invoke.apply(proxies['chatHub'], $.merge(["checkin"], $.makeArray(arguments)));
             },

            clearSession: function () {
                return proxies['chatHub'].invoke.apply(proxies['chatHub'], $.merge(["ClearSession"], $.makeArray(arguments)));
             },

            connecttoLead: function (connectionID, mobileNo) {
                return proxies['chatHub'].invoke.apply(proxies['chatHub'], $.merge(["ConnecttoLead"], $.makeArray(arguments)));
             },

            disconnectFromDashboard: function (uid) {
                return proxies['chatHub'].invoke.apply(proxies['chatHub'], $.merge(["DisconnectFromDashboard"], $.makeArray(arguments)));
             },

            disconnectUser: function (connectionID, messageKey, disposition, subDisposition, comment, rating, callBackDate) {
                return proxies['chatHub'].invoke.apply(proxies['chatHub'], $.merge(["disconnectUser"], $.makeArray(arguments)));
             },

            geChattDatafromHistory: function (emailid, chatdatareturn) {
                return proxies['chatHub'].invoke.apply(proxies['chatHub'], $.merge(["geChattDatafromHistory"], $.makeArray(arguments)));
             },

            generateLeadURL: function (userConnectionId, connectionID) {
                return proxies['chatHub'].invoke.apply(proxies['chatHub'], $.merge(["GenerateLeadURL"], $.makeArray(arguments)));
             },

            getAndSendOffline: function (data) {
                return proxies['chatHub'].invoke.apply(proxies['chatHub'], $.merge(["GetAndSendOffline"], $.makeArray(arguments)));
             },

            getCallStatusList: function (usr) {
                return proxies['chatHub'].invoke.apply(proxies['chatHub'], $.merge(["GetCallStatusList"], $.makeArray(arguments)));
             },

            getStandardText: function (usr) {
                return proxies['chatHub'].invoke.apply(proxies['chatHub'], $.merge(["getStandardText"], $.makeArray(arguments)));
             },

            getStandardTextValue: function (id, conid) {
                return proxies['chatHub'].invoke.apply(proxies['chatHub'], $.merge(["getStandardTextValue"], $.makeArray(arguments)));
             },

            getStandardTextValueBySform: function (sForm, conid) {
                return proxies['chatHub'].invoke.apply(proxies['chatHub'], $.merge(["getStandardTextValueBySform"], $.makeArray(arguments)));
             },

            getSubCallStatusList: function (usr) {
                return proxies['chatHub'].invoke.apply(proxies['chatHub'], $.merge(["GetSubCallStatusList"], $.makeArray(arguments)));
             },

            getUserAuthenticationHistory: function (retrivedData) {
                return proxies['chatHub'].invoke.apply(proxies['chatHub'], $.merge(["GetUserAuthenticationHistory"], $.makeArray(arguments)));
             },

            landedURL: function (URL, connectionId) {
                return proxies['chatHub'].invoke.apply(proxies['chatHub'], $.merge(["LandedURL"], $.makeArray(arguments)));
             },

            login: function (parameter) {
                return proxies['chatHub'].invoke.apply(proxies['chatHub'], $.merge(["Login"], $.makeArray(arguments)));
             },

            logOffUser: function () {
                return proxies['chatHub'].invoke.apply(proxies['chatHub'], $.merge(["logOffUser"], $.makeArray(arguments)));
             },

            newOperator: function (name, connectionID) {
                return proxies['chatHub'].invoke.apply(proxies['chatHub'], $.merge(["newOperator"], $.makeArray(arguments)));
             },

            newUser: function (uInfo) {
                return proxies['chatHub'].invoke.apply(proxies['chatHub'], $.merge(["newUser"], $.makeArray(arguments)));
             },

            opeartorTimeOut: function () {
                return proxies['chatHub'].invoke.apply(proxies['chatHub'], $.merge(["opeartorTimeOut"], $.makeArray(arguments)));
             },

            operatorLogOut: function () {
                return proxies['chatHub'].invoke.apply(proxies['chatHub'], $.merge(["operatorLogOut"], $.makeArray(arguments)));
             },

            removeUser: function (name) {
                return proxies['chatHub'].invoke.apply(proxies['chatHub'], $.merge(["removeUser"], $.makeArray(arguments)));
             },

            removeUserFromClient: function (connectionId, opConId) {
                return proxies['chatHub'].invoke.apply(proxies['chatHub'], $.merge(["RemoveUserFromClient"], $.makeArray(arguments)));
             },

            removeUserFromClientCallByClient: function (connectionId) {
                return proxies['chatHub'].invoke.apply(proxies['chatHub'], $.merge(["RemoveUserFromClientCallByClient"], $.makeArray(arguments)));
             },

            resetOperatorStatus: function () {
                return proxies['chatHub'].invoke.apply(proxies['chatHub'], $.merge(["resetOperatorStatus"], $.makeArray(arguments)));
             },

            resetPassword: function (oldpwd, newpwd) {
                return proxies['chatHub'].invoke.apply(proxies['chatHub'], $.merge(["resetPassword"], $.makeArray(arguments)));
             },

            saveCallStatus: function (statusOptionid, statusSubOptionid, comment, connectionID, callbkdatetime) {
                return proxies['chatHub'].invoke.apply(proxies['chatHub'], $.merge(["saveCallStatus"], $.makeArray(arguments)));
             },

            saveGuestinfoSrv: function (name, emailid, mobileno, connectionID) {
                return proxies['chatHub'].invoke.apply(proxies['chatHub'], $.merge(["SaveGuestinfoSrv"], $.makeArray(arguments)));
             },

            saveRatingForAgent: function (connectionID, rating) {
                return proxies['chatHub'].invoke.apply(proxies['chatHub'], $.merge(["SaveRatingForAgent"], $.makeArray(arguments)));
             },

            sendLocation: function (userConnectionId, latitude, longitude) {
                return proxies['chatHub'].invoke.apply(proxies['chatHub'], $.merge(["sendLocation"], $.makeArray(arguments)));
             },

            sendMailToUser: function (connectionId, receiverMailId, type) {
                return proxies['chatHub'].invoke.apply(proxies['chatHub'], $.merge(["sendMailToUser"], $.makeArray(arguments)));
             },

            sendMessage: function (formattedDate, fromName, fromId, toId, message) {
                return proxies['chatHub'].invoke.apply(proxies['chatHub'], $.merge(["sendMessage"], $.makeArray(arguments)));
             },

            sendMessageTyping: function (formattedDate, fromName, fromId, toId, message) {
                return proxies['chatHub'].invoke.apply(proxies['chatHub'], $.merge(["sendMessageTyping"], $.makeArray(arguments)));
             },

            sendOfflineMessageIfAny: function (connectionId) {
                return proxies['chatHub'].invoke.apply(proxies['chatHub'], $.merge(["SendOfflineMessageIfAny"], $.makeArray(arguments)));
             },

            sendStatusReceived: function (connectionID, callerType) {
                return proxies['chatHub'].invoke.apply(proxies['chatHub'], $.merge(["SendStatusReceived"], $.makeArray(arguments)));
             },

            sendStatusSeen: function (connectionID, callerType) {
                return proxies['chatHub'].invoke.apply(proxies['chatHub'], $.merge(["SendStatusSeen"], $.makeArray(arguments)));
             },

            sendStatusSeenAll: function (emailid) {
                return proxies['chatHub'].invoke.apply(proxies['chatHub'], $.merge(["SendStatusSeenAll"], $.makeArray(arguments)));
             },

            transferUserToOtherOperator: function (userConnectionID, operatorfromConnectionID, operatortoConnectionID, chatDuration) {
                return proxies['chatHub'].invoke.apply(proxies['chatHub'], $.merge(["TransferUserToOtherOperator"], $.makeArray(arguments)));
             },

            updateAgentLoginStatusSrv: function () {
                return proxies['chatHub'].invoke.apply(proxies['chatHub'], $.merge(["UpdateAgentLoginStatusSrv"], $.makeArray(arguments)));
             },

            updateCallStatusClient: function (connectionID) {
                return proxies['chatHub'].invoke.apply(proxies['chatHub'], $.merge(["UpdateCallStatusClient"], $.makeArray(arguments)));
             },

            updateChatDataPeriodically: function (connectionID) {
                return proxies['chatHub'].invoke.apply(proxies['chatHub'], $.merge(["UpdateChatDataPeriodically"], $.makeArray(arguments)));
             },

            updateLeadConnectionId: function (usrconnectionId) {
                return proxies['chatHub'].invoke.apply(proxies['chatHub'], $.merge(["updateLeadConnectionId"], $.makeArray(arguments)));
             },

            updateOperatorConnectionId: function (opconnectionId) {
                return proxies['chatHub'].invoke.apply(proxies['chatHub'], $.merge(["updateOperatorConnectionId"], $.makeArray(arguments)));
             },

            validateUser: function (uname, pwd) {
                return proxies['chatHub'].invoke.apply(proxies['chatHub'], $.merge(["validateUser"], $.makeArray(arguments)));
             },

            visitedUrls: function (urls, connectionID) {
                return proxies['chatHub'].invoke.apply(proxies['chatHub'], $.merge(["VisitedUrls"], $.makeArray(arguments)));
             }
        };

        return proxies;
    };

    signalR.hub = $.hubConnection("/signalr", { useDefaultPath: false });
    $.extend(signalR, signalR.hub.createHubProxies());

}(window.jQuery, window));